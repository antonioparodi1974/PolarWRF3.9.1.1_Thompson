#ifdef DEREF_KLUDGE
         sm31             = grid%sm31
         em31             = grid%em31
         sm32             = grid%sm32
         em32             = grid%em32
         sm33             = grid%sm33
         em33             = grid%em33

         sm31x            = grid%sm31x
         em31x            = grid%em31x
         sm32x            = grid%sm32x
         em32x            = grid%em32x
         sm33x            = grid%sm33x
         em33x            = grid%em33x

         sm31y            = grid%sm31y
         em31y            = grid%em31y
         sm32y            = grid%sm32y
         em32y            = grid%em32y
         sm33y            = grid%sm33y
         em33y            = grid%em33y
#endif

